<?php

function dd ($data) {
	die(var_dump($data));
}