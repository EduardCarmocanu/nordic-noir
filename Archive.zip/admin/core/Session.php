<?php

class Session {
	// ...
}